package com.example.community.Community.ui.CarPooling

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.community.Authentication.VerifyUserViewModel
import com.example.community.Community.domain.model.AddressData
import com.example.community.Community.domain.model.RegisterVehicleModel
import com.example.community.Community.domain.model.VehicleData
import com.example.community.Community.ui.Authentication.MainActivity
import com.example.community.R
import com.example.community.databinding.FragmentOwnerInfoBinding


class OwnerInfoFragment : Fragment() {

    private var _binding : FragmentOwnerInfoBinding?=null
    private val binding get() = _binding!!

    private val viewModel : CarPoolingViewModel by lazy {
        (requireActivity() as UserInteractionActivity).carPoolingViewModel
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding= FragmentOwnerInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.submitDetails.setOnClickListener {
            var addressLine1 = binding.addressLine1.text.toString()
            var addressLine2 = binding.addressLine2.text.toString()
            var city = binding.city.text.toString()
            var pincode = binding.pincode.text.toString()
            var vehicleType = binding.vehileType.text.toString()
            var vehicleNumber = binding.vehicleNumber.text.toString()
            var occupiedSeats = binding.occupiedSeats.text.toString()

            var registerVehicleModel = RegisterVehicleModel(AddressData(null,addressLine1,addressLine2,city, pincode), VehicleData(null,vehicleType,vehicleNumber,occupiedSeats.toInt()))

            viewModel.sendRegisterDetails(registerVehicleModel)
        }

        viewModel.registerSuccessfull.observe(viewLifecycleOwner){
            //Open another fragment
            findNavController().navigate(R.id.action_ownerInfoFragment_to_registerOrCreateNew)
        }
    }

    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            OwnerInfoFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }
}