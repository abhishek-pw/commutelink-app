package com.example.community.Community.domain.mapper

abstract class Mapper<Dto,Domain> {
    abstract fun dtoToDomain(dto:Dto) : Domain
}