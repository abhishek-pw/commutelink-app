package com.example.community.Community.network

import com.example.community.Community.domain.model.GetRideDtoModel
import com.example.community.Community.domain.model.PostRideDtoModel
import com.example.community.Community.domain.model.RegisterVehicleModel
import com.example.community.Community.network.dto.LoginResponseDto
import com.example.community.Community.network.dto.LoginUserDto
import com.example.community.Community.network.dto.VerifyUserBody
import com.example.community.Community.network.dto.VerifyUserDto
import com.example.community.Community.ui.CarPooling.GetNearByVehiclesDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface CommunityService {
    @POST("/commutelink/public-api/v1/login")
    suspend fun loginUser(
        @Body loginUserDto: LoginUserDto
    ) : Response<LoginResponseDto>

    @POST("/commutelink/public-api/v1/verify")
    suspend fun verifyUser(
        @Body verifyUserBody: VerifyUserBody
    ) : Response<VerifyUserDto>

    @POST("/commutelink/api/v1/profile")
    suspend fun registerVehicle(
        @Body registerVehicleModel: RegisterVehicleModel
    ) : Response<RegisterVehicleModel>

    @GET("/commutelink/api/v1/profile")
    suspend fun getRegisteredInfo() : Response<RegisterVehicleModel>

    @POST("/api/v1/trip")
    suspend fun postRide(
        @Body postRideDtoModel: PostRideDtoModel
    ) : Response<PostRideDtoModel>

    @GET("/api/v1/user-trip")
    suspend fun getRide() : Response<List<GetRideDtoModel>>

    @GET("/api/v1/trip")
    suspend fun findSaarthi(
        @Query("latitude") latitude : Double,
        @Query("longitude") longitude : Double,
        @Query("radius") radius : Double,
        @Query("lookingFor") lookingFor : String
    ) : Response<List<GetNearByVehiclesDto>>
}