package com.example.community.Community.network.dto

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class VerifyUserDto(
    @SerializedName("access")
    var access : TokenDto,

    @SerializedName("refresh")
    var refresh : TokenDto

) : Parcelable