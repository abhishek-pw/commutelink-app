package com.example.community.Authentication

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.community.Community.network.CommunityService
import com.example.community.Community.network.dto.LoginResponseDto
import com.example.community.Community.network.dto.LoginUserDto
import com.example.community.Community.network.dto.VerifyUserBody
import com.example.community.Community.network.dto.VerifyUserDto
import com.example.community.RetrofitHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response

class VerifyUserViewModel : ViewModel(){

    private val _verifiedUser = MutableLiveData<String>()

    val verifiedUser = _verifiedUser

    private val _loginUser = MutableLiveData<String?>()
    val loginUser = _loginUser

    private val _moveToOtp = MutableLiveData<Boolean>()
    val moveToOtp = _moveToOtp


    val userLoginApi = RetrofitHelper.getInstance().create(CommunityService::class.java)


     fun startVerifyingUser(refId: String?,otp : String?){
        viewModelScope.launch(Dispatchers.IO) {
            val verificationToken = verifyUser(refId!!,otp!!)
            _verifiedUser.postValue(verificationToken.body()!!.access.token)

        }
    }

    suspend fun verifyUser(refId : String,otp:String): Response<VerifyUserDto> {
        return  userLoginApi.verifyUser(VerifyUserBody(refId,otp))
    }


    fun startLoginUser(name : String, number : String){
        viewModelScope.launch(Dispatchers.IO) {
            val result = loginUser(name,number)
            _loginUser.postValue(result.body()?.refId)
            _moveToOtp.postValue(true)
        }


    }

    suspend fun loginUser(name: String, number: String) : Response<LoginResponseDto>{
        return userLoginApi.loginUser(LoginUserDto(number,name))
    }

}