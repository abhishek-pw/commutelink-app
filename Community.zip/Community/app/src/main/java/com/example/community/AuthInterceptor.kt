package com.example.community

import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val authToken : String) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()

        // Add the authentication token to the request headers
        val requestWithAuth = originalRequest.newBuilder()
            .header("Authorization", "Bearer $authToken")
            .build()

        return chain.proceed(requestWithAuth)
    }

}