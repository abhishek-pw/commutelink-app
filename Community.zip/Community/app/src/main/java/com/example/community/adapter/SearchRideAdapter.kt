package com.example.community.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.community.Community.domain.model.GetRideDomainModel
import com.example.community.Community.ui.CarPooling.GetNearByVehiclesDto
import com.example.community.R
import com.example.community.databinding.ScheduledItemLayoutBinding
import com.example.community.databinding.SearchDestinationItemBinding

class SearchRideAdapter(private val list: List<GetNearByVehiclesDto>) : RecyclerView.Adapter<SearchRideAdapter.SearchViewHolder>() {

    inner class SearchViewHolder(private val item: SearchDestinationItemBinding) : RecyclerView.ViewHolder(item.root) {
        var userName = item.userName
        val tripStatus = item.tripStatus
        val distanceAway = item.distanceInM
        val tripDate = item.tripDate
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchViewHolder {
        val binding = DataBindingUtil.inflate<SearchDestinationItemBinding>(LayoutInflater.from(parent.context), R.layout.search_destination_item, parent, false)
        return SearchViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: SearchViewHolder, position: Int) {
        val item = list[position]
        holder.apply {
            userName.text = item.name
            tripStatus.text = item.tripStatus
            distanceAway.text = item.distance.toString()
            tripDate.text = item.tripDate
        }
    }

}

