package com.example.community.Community.domain.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class GetRideDtoModel(

    @SerializedName("name")
    val name : String,

    @SerializedName("coordinates")
    val coordinates: Coordinates,

    @SerializedName("distance")
    val distance : Int,

    @SerializedName("type")
    val type : String,

    @SerializedName("tripId")
    val typeId : String,

    @SerializedName("createdAt")
    val createdAt : String,

    @SerializedName("tripStatus")
    val tripStatus : String,

    @SerializedName("tripDate")
    val tripDate : String

) : Parcelable{
    fun coordinatesToLocation(){

    }
}