package com.example.community.Community.network.dto

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class LoginUserDto(
    @SerializedName("mobile")
    val mobile : String,

    @SerializedName("name")
    val name : String
): Parcelable