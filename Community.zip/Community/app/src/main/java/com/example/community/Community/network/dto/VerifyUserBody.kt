package com.example.community.Community.network.dto

import com.google.gson.annotations.SerializedName

data class VerifyUserBody(
    @SerializedName("refId")
    var refId : String,

    @SerializedName("otp")
    var otp : String
)