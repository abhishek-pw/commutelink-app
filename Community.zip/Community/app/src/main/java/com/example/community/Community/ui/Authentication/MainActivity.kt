package com.example.community.Community.ui.Authentication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.community.Authentication.VerifyUserViewModel
import com.example.community.R


class MainActivity : AppCompatActivity() {
    lateinit var verifyUserViewModel: VerifyUserViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        verifyUserViewModel = ViewModelProvider(this)[VerifyUserViewModel::class.java]
    }
}