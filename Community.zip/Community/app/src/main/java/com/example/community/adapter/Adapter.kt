package com.example.community.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.community.Community.domain.model.GetRideDomainModel
import com.example.community.Community.domain.model.GetRideDtoModel
import com.example.community.R
import com.example.community.databinding.ScheduledItemLayoutBinding

class Adapter(private val list: List<GetRideDomainModel>) : RecyclerView.Adapter<Adapter.ViewHolder>() {

    inner class ViewHolder(private val item: ScheduledItemLayoutBinding) : RecyclerView.ViewHolder(item.root) {

        var userLocation = item.userLocation
        val time = item.time
        val statusUpdate = item.statusUpdate
        val distanceInM = item.distanceInM

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = DataBindingUtil.inflate<ScheduledItemLayoutBinding>(LayoutInflater.from(parent.context), R.layout.scheduled_item_layout, parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.apply {
            userLocation.text = item.locationName
            statusUpdate.text = item.tripStatus
            time.text = item.createdAt
            distanceInM.text = item.distance.toString()
        }
    }

}

