package com.example.community.Community.domain.mapper

import android.content.Context
import android.location.Address
import android.location.Geocoder
import com.example.community.Community.domain.model.GetRideDomainModel
import com.example.community.Community.domain.model.GetRideDtoModel
import java.io.IOException
import java.util.Locale

class scheduledRidesMapper(private val context : Context) : Mapper<GetRideDtoModel,GetRideDomainModel>() {
    override fun dtoToDomain(dto: GetRideDtoModel): GetRideDomainModel {

        return GetRideDomainModel(
            name = dto.name,
            locationName = coordinatesToLocation(dto.coordinates.latitude, dto.coordinates.longitude, context = context),
            distance = dto.distance,
            type = dto.type,
            typeId = dto.typeId,
            createdAt = dto.createdAt,
            tripStatus = dto.tripStatus,
            tripDate = dto.tripDate
        )
    }

    companion object {
        fun coordinatesToLocation(lat: Double, lng: Double, context: Context): String {
            val reverseGeocoder: Geocoder = Geocoder(context, Locale.getDefault())
            var addressString: String? = null
            try {
                val addresses: List<Address> = reverseGeocoder.getFromLocation(lat, lng, 1)!!
                if (addresses.isNotEmpty()) {
                    val address: Address = addresses[0]

                    // Build the address string from address components
                    val addressBuilder = StringBuilder()

                    val addressLineCount = address.maxAddressLineIndex
                    for (i in 0..addressLineCount) {
                        addressBuilder.append(address.getAddressLine(i))
                        if (i < addressLineCount) {
                            addressBuilder.append(", ") // Add a separator if there are more lines
                        }
                    }

                    addressString = addressBuilder.toString()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }

            return addressString!!
        }
    }
}
