package com.example.community

abstract class Mapper<Domain, Dto> {
    abstract fun dtoDomain() : Domain
    abstract fun domainToDto() : Dto
}