package com.example.community.Community.ui.CarPooling

import android.os.Parcelable
import com.example.community.Community.domain.model.Coordinates
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class GetNearByVehiclesDto(
    @SerializedName("name")
    val name : String,

    @SerializedName("coordinates")
    val coordinates: Coordinates,

    @SerializedName("distance")
    val distance : Double,

    @SerializedName("type")
    val type : String,

    @SerializedName("tripId")
    val tripId : String,

    @SerializedName("createdAt")
    val createdAt : String,

    @SerializedName("tripStatus")
    val tripStatus : String,

    @SerializedName("tripDate")
    val tripDate : String
) : Parcelable
