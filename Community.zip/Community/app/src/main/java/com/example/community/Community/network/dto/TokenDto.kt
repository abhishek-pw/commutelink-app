package com.example.community.Community.network.dto

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class TokenDto(
    @SerializedName("token")
    var token : String,

    @SerializedName("expire")
    var expire : Int,

    @SerializedName("tokenType")
    var tokenType : String?
) : Parcelable