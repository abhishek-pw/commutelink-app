package com.example.community.Community.domain.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

data class PostRideDtoModel(
    val triptype : String,
    val startPoint : Coordinates,
    var endPoint : Coordinates,
    val vehicleId : String,
    val groupSize : Int,
    val tripDate : String,
    val tripTime : String
)

@Parcelize
data class Coordinates(
    @SerializedName("latitude")
    val latitude : Double,

    @SerializedName("longitude")
    val longitude : Double
) : Parcelable
