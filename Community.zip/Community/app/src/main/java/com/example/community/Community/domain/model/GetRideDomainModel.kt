package com.example.community.Community.domain.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class GetRideDomainModel(
    val name : String? = null,

    val locationName: String,

    val distance : Int,

    val type : String,

    val typeId : String,

    val createdAt : String,

    val tripStatus : String,

    val tripDate : String
) : Parcelable