package com.example.community.Community.network.dto

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class LoginResponseDto(
    @SerializedName("isNew")
    var isNewUser : Boolean,

    @SerializedName("refId")
    var refId : String,

    @SerializedName("mobileNumber")
    var mobileNumber : String?,

    @SerializedName("userId")
    var userId : String

) : Parcelable