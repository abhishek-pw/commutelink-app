package com.example.community.Community.ui.CarPooling

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.community.Community.domain.model.GetRideDtoModel
import com.example.community.Community.domain.model.PostRideDtoModel
import com.example.community.Community.domain.model.RegisterVehicleModel
import com.example.community.Community.network.CommunityService
import com.example.community.RetrofitHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CarPoolingViewModel : ViewModel() {

    val carPoolingApi = RetrofitHelper.getInstance().create(CommunityService::class.java)

    val _registerSuccessfull = MutableLiveData<RegisterVehicleModel>()
    val registerSuccessfull = _registerSuccessfull

    val _getRegisteredInfo = MutableLiveData<RegisterVehicleModel>()
    val getRegisteredInfo = _getRegisteredInfo

    val _postRide = MutableLiveData<PostRideDtoModel>()
    val postRide = _postRide

    val _getRide = MutableLiveData<List<GetRideDtoModel>>()
    val getRide = _getRide

    val _getNearBySaarthi = MutableLiveData<List<GetNearByVehiclesDto>>()
    val getNearBySaarthi = _getNearBySaarthi

    val loading = MutableLiveData<Boolean>()

    fun sendRegisterDetails(registerVehicleModel: RegisterVehicleModel){

        viewModelScope.launch(Dispatchers.IO) {
            val result = carPoolingApi.registerVehicle(registerVehicleModel)
            _registerSuccessfull.postValue(result.body())
        }

    }

    fun getVehicleId(){
        viewModelScope.launch(Dispatchers.IO) {
            val result = carPoolingApi.getRegisteredInfo()
            _getRegisteredInfo.postValue(result.body())
        }
    }

    fun postRide(postRideDtoModel: PostRideDtoModel){

        viewModelScope.launch(Dispatchers.IO) {
            val result = carPoolingApi.postRide(postRideDtoModel)
            _postRide.postValue(result.body())
        }

    }

    fun getRide(){

        viewModelScope.launch(Dispatchers.IO) {
            val result = carPoolingApi.getRide()
            _getRide.postValue(result.body())
        }

    }

    fun getNearBySaarthi(lattitude: Double, longitude : Double, radius : Double,place : String ="asdfasdf" ) {

        viewModelScope.launch(Dispatchers.IO) {
            val result = carPoolingApi.findSaarthi(lattitude,longitude,radius,place)
            _getNearBySaarthi.postValue(result.body())
        }

    }

}