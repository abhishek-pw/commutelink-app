package com.example.community.Community.ui.CarPooling

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.community.Community.domain.mapper.scheduledRidesMapper
import com.example.community.Community.domain.model.GetRideDomainModel
import com.example.community.R
import com.example.community.adapter.Adapter
import com.example.community.databinding.FragmentSecondBinding
import com.example.community.databinding.FragmentYourRidesBinding


class YourRidesFragment : Fragment() {

    private val viewModel : CarPoolingViewModel by lazy {
        (requireActivity() as UserInteractionActivity).carPoolingViewModel
    }

    private var _binding: FragmentYourRidesBinding? = null

    private val binding get() = _binding!!

    private var recyclerView : RecyclerView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentYourRidesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = binding.scheduledRidesList
        recyclerView!!.layoutManager = LinearLayoutManager(requireContext())
        viewModel.getRide()

        viewModel.getRide.observe(viewLifecycleOwner){
            //List of rides

            val getRideDomainList = ArrayList<GetRideDomainModel>()
            var size = 0
            if(it!=null) {
                 size = it.size
            }
            if(it!=null){
                it.forEach {
                    val scheduledDomain = scheduledRidesMapper(requireContext()).dtoToDomain(it)
                    getRideDomainList.add(scheduledDomain)
                }
            }

            if(size == 0){
                createDummyData(getRideDomainList)
            }

            val adapter : Adapter = Adapter(getRideDomainList)
            recyclerView!!.adapter = adapter


        }
    }

    private fun createDummyData(createDummy :ArrayList<GetRideDomainModel>){
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))
        createDummy.add(GetRideDomainModel("Abhishek","Gurgaon MG Road",6,"user pick","42423","4.00","active","4-8-2023"))


    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment YourRidesFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            YourRidesFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }
}