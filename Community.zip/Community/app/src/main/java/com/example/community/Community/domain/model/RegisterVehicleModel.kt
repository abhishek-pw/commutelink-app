package com.example.community.Community.domain.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class RegisterVehicleModel (
    @SerializedName("addressData")
    var addressData : AddressData,

    @SerializedName("vehicleData")
    var vehicleData : VehicleData?
) : Parcelable


@Parcelize
data class AddressData(

    @SerializedName("id")
    var id : String?=null,

    @SerializedName("addressline1")
    var addressline1:String,

    @SerializedName("addressline2")
    var addressLine2:String,

    @SerializedName("city")
    var city: String,

    @SerializedName("pincode")
    var pincode: String
):Parcelable

@Parcelize
data class VehicleData(

    @SerializedName("id")
    var id : String?=null,

    @SerializedName("vehicleType")
    var vehicleType : String,

    @SerializedName("vehicleNumber")
    var vehicleNumber : String,

    @SerializedName("offerSeats")
    var offerSeats : Int

):Parcelable