package com.example.community.Community.ui.CarPooling

import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.community.R
import com.example.community.adapter.SearchRideAdapter
import com.example.community.databinding.FragmentAvailableRidesBinding
import com.example.community.databinding.FragmentYourRidesBinding


class AvailableRidesFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    lateinit var geocoder : Geocoder

    private var recyclerView : RecyclerView? = null

    private val viewModel : CarPoolingViewModel by lazy {
        (requireActivity() as UserInteractionActivity).carPoolingViewModel
    }

    private var _binding: FragmentAvailableRidesBinding? = null

    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding =  FragmentAvailableRidesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        geocoder = Geocoder(requireActivity())
        recyclerView = binding.sameDestinationRv
        recyclerView?.layoutManager = LinearLayoutManager(requireContext())
        binding.Search.setOnClickListener {
            val address = binding.destinationLocation.text.toString()
            val latlng = createlatLngFromAddress(address,1)
            viewModel.getNearBySaarthi(28.609839728401678,77.45466979615413,1000.00,"Sec-59")
        }
        viewModel.getNearBySaarthi.observe(viewLifecycleOwner){
                //Submit list to adapter
            val adapter = SearchRideAdapter(it)
            recyclerView?.adapter = adapter

        }

    }

    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            AvailableRidesFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }

    private fun createlatLngFromAddress(address : String, maxResult : Int): Pair<Double, Double> {

        try {
            val addressList: List<Address> = geocoder.getFromLocationName(address, maxResult)!!
            if (addressList.isNotEmpty()) {
                val latitude = addressList[0].latitude
                val longitude = addressList[0].longitude
                // Now, latitude and longitude hold the coordinates
                println("Latitude: $latitude, Longitude: $longitude")
                return latitude to longitude
            } else {
                println("Address not found")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Pair(0.0,0.0)
    }
}