package com.example.community

class Constants {

    companion object{
        val BASE_URL = "https://b93e-14-194-100-174.ngrok-free.app/"
    }
}