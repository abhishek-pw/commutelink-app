package com.example.community

import com.example.community.Constants.Companion.BASE_URL
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitHelper {

    val authToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI5MzU0NTUyMjM3Iiwic3ViamVjdCI6IjkzNTQ1NTIyMzciLCJuYW1lIjoiQWJoc2loZWsiLCJ0eXBlIjoiYWNjZXNzIiwidXNlcklkIjoiNjUyODAxYWI0Y2ZlZmI2NTdlZGI4NDVkIiwiZXhwIjoxNjk3MzE3NDA4LCJpc3MiOiJQVyJ9.rzyMLxNMdlT-NbwbE8yXEZX5cKgNgZlQfrlGUxf6vXQ"

    val authInterceptor = AuthInterceptor(authToken)

    val okhttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .build()

    fun getInstance(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okhttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

}