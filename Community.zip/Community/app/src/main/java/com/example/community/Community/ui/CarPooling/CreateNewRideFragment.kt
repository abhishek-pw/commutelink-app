package com.example.community.Community.ui.CarPooling

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.community.Community.domain.model.Coordinates
import com.example.community.Community.domain.model.PostRideDtoModel
import com.example.community.R
import com.example.community.databinding.FragmentCreateNewRideBinding
import com.example.community.databinding.FragmentOwnerInfoBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import java.util.Calendar


class CreateNewRideFragment : Fragment() {

    lateinit var geocoder : Geocoder

    private val viewModel : CarPoolingViewModel by lazy {
        (requireActivity() as UserInteractionActivity).carPoolingViewModel
    }

    private var _binding : FragmentCreateNewRideBinding?=null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding= FragmentCreateNewRideBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
         geocoder = Geocoder(requireActivity())

        binding.calender.setOnClickListener {
            showDatePickerDialog()
        }

        binding.tripTime.setOnClickListener {
            showTimePickerDialog()
        }

        viewModel.getVehicleId()

        viewModel.getRegisteredInfo.observe(viewLifecycleOwner){registeredVehicle->
            binding.createRide.setOnClickListener {view->
                viewModel.loading.value = true
                val destinationAddress = binding.destination.text.toString()
                val startingPointAddress = binding.startingPoint.text.toString()
                val destinationLatLng = createlatLngFromAddress(destinationAddress,1)
                val startingPointLatLng = createlatLngFromAddress(startingPointAddress,1)
                val vehicleId = registeredVehicle.vehicleData?.id
                val groupSize = binding.groupSize.text.toString()
                val tripDate = binding.tripDate.text.toString()
                val tripTime = binding.selectTime.text.toString()

                if(destinationAddress!=""&&startingPointAddress!=""&&destinationLatLng.first!=0.0&&startingPointLatLng.first!=0.0 && vehicleId != "" && groupSize != "" && tripDate != ""){
                    viewModel.postRide(PostRideDtoModel(
                        "DRIVER_OFFER",
                        Coordinates(startingPointLatLng.first,startingPointLatLng.second),
                        Coordinates(destinationLatLng.first,destinationLatLng.second),
                        vehicleId!!,
                        groupSize.toInt(),
                        tripDate,
                        tripTime
                    ))
                }else{
                    Toast.makeText(requireContext(),"Please fill all the details",Toast.LENGTH_SHORT).show()
                }




            }
        }

        viewModel.postRide.observe(viewLifecycleOwner){postRide->
            viewModel.loading.value = false
            findNavController().navigate(R.id.action_createNewRideFragment_to_registerOrCreateNew)

        }

    }

    private fun createlatLngFromAddress(address : String, maxResult : Int): Pair<Double, Double> {

        try {
            val addressList: List<Address> = geocoder.getFromLocationName(address, maxResult)!!
            if (addressList.isNotEmpty()) {
                val latitude = addressList[0].latitude
                val longitude = addressList[0].longitude
                // Now, latitude and longitude hold the coordinates
                println("Latitude: $latitude, Longitude: $longitude")
                return latitude to longitude
            } else {
                println("Address not found")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Pair(0.0,0.0)
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(), DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            // The user has selected a date
            val selectedDate = "$year-${month + 1}-$dayOfMonth" // Adjust month (0-based)
            // Do something with the selectedDate string
            binding.tripDate.text = selectedDate
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun showTimePickerDialog(){
        val currentTime = Calendar.getInstance()
        val hour = currentTime.get(Calendar.HOUR_OF_DAY)
        val minute = currentTime.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            requireContext(),
            TimePickerDialog.OnTimeSetListener { view, selectedHour, selectedMinute ->
                // Handle the selected time (selectedHour and selectedMinute)

                val selectedHour = selectedHour.toString()
                var selectedMin = selectedMinute.toString()
                var time = ""
                if(selectedHour.length==1 && selectedMin.length>1 )
                {
                     time =  "0$selectedHour-$selectedMinute"
                }else if(selectedHour.length>1 && selectedMin.length==1 ){
                    time =  "$selectedHour-0$selectedMinute"

                }else if(selectedHour.length==1 && selectedMin.length==1 ){
                    time = "0$selectedHour-0$selectedMinute"
                }else{
                    time = "$selectedHour-$selectedMinute"
                }
                runBlocking {
                    delay(2000)
                }
                binding.selectTime.text = time
                // This callback is triggered when the user sets the time in the dialog.
            },
            hour, minute, true // true for 24-hour format, false for 12-hour format
        )

        timePickerDialog.show()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment CreateNewRideFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            CreateNewRideFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }
}