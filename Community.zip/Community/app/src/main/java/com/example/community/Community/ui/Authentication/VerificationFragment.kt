package com.example.community.Community.ui.Authentication

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.community.Authentication.VerifyUserViewModel
import com.example.community.Community.ui.CarPooling.UserInteractionActivity
import com.example.community.databinding.FragmentVerificationBinding

class VerificationFragment : Fragment() {

    private var _binding : FragmentVerificationBinding?=null
    private val binding get() = _binding!!

    private val viewModel : VerifyUserViewModel by lazy {
        (requireActivity() as MainActivity).verifyUserViewModel
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentVerificationBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.otpView.setOtpCompletionListener {otp->
            viewModel.loginUser.observe(viewLifecycleOwner){refId->
                viewModel.startVerifyingUser(refId,otp)
            }
        }



        viewModel.verifiedUser.observe(viewLifecycleOwner){
            //Store the token in db and move it to the next Screen
            val intent = Intent(requireContext(), UserInteractionActivity::class.java)
            startActivity(intent)
        }
    }

    companion object {

        fun newInstance(param1: String, param2: String) =
            VerificationFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}