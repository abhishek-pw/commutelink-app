package com.example.community.Community.ui.Authentication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.community.Authentication.VerifyUserViewModel
import com.example.community.R
import com.example.community.databinding.FragmentLoginBinding

class SignUpFragment : Fragment() {

    private var _binding : FragmentLoginBinding?=null
    private val binding get() = _binding!!


    private val viewModel : VerifyUserViewModel by lazy {
        (requireActivity() as MainActivity).verifyUserViewModel
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentLoginBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.signUpButton.setOnClickListener {
            val name = binding.username.text
            val number = binding.number.text
            viewModel.startLoginUser(name.toString(),number.toString())

        }

        viewModel.moveToOtp.observe(viewLifecycleOwner){
            findNavController().navigate(R.id.action_loginFragment_to_verificationFragment)
        }



    }

    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            SignUpFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}