package com.example.community.Community.ui.CarPooling

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.community.Authentication.VerifyUserViewModel
import com.example.community.R
import com.example.community.databinding.ActivityUserInteractionBinding

class UserInteractionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserInteractionBinding
    lateinit var carPoolingViewModel: CarPoolingViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityUserInteractionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        carPoolingViewModel = ViewModelProvider(this)[CarPoolingViewModel::class.java]

        val navController = findNavController(R.id.nav_host_fragment_content_user_interaction)

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_user_interaction)
        return navController.navigateUp()
                || super.onSupportNavigateUp()
    }
}